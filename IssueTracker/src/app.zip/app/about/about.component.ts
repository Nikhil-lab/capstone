import { Component } from '@angular/core';

@Component({
  template: '<h3>ABOUT: Product Inventory Application</h3>'
})
export class AboutComponent { }
