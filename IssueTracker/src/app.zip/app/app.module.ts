import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent }  from './app.component';
import { routing }  from './app.routing';

import {AboutComponent} from './about/about.component';
import { IssuesService } from './products/products.service';
import { IssuesModule } from './products/products.module';
import { SharedModule } from './shared/shared.module';
import { PageNotFoundComponent } from './page-not-found.component';

@NgModule({
  imports: [ BrowserModule, FormsModule,HttpClientModule,routing ],
  declarations: [ AppComponent, AboutComponent,PageNotFoundComponent],
  providers:[IssuesService],
  bootstrap: [ AppComponent ]
})
export class AppModule { }



//declarations: [ AppComponent, AboutComponent, IssuesComponent, IssueComponent, AddIssueFormComponent, EditIssueFormComponent, IssueFilterPipe ],