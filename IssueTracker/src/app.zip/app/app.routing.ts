import { Routes, RouterModule } from '@angular/router';

import {AboutComponent} from './about/about.component';
import { PageNotFoundComponent } from './page-not-found.component';


const appRoutes: Routes = [
  { path: '', component: AboutComponent },
  //{path:'product', loadChildren:()=> import('./products/products.module').then(m=>m.IssuesModule)},
  {path:'products', loadChildren: './products/products.module#IssuesModule'},
  {path:'**', component:PageNotFoundComponent}
];

export const routing = RouterModule.forRoot(appRoutes);
