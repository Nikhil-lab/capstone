import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

import { IssuesService } from "./products.service";

@Component({
  selector: 'editproduct-form',
  templateUrl: './editproduct-form.component.html'
})
export class EditIssueFormComponent {
	id: any;
  product: any;
  products:any[];

  

  constructor(private _issueService: IssuesService, private route: ActivatedRoute, private router: Router) { }
  
  
  getFun(){
	
	this._issueService.getIssues().subscribe(
      (x:any) =>  this.products = x,
      err => console.log(err)
    );
	
	
}

  ngOnInit(): void {
      this.route.params.forEach((params: Params) => {
          this.id = +params['id'];
      });
	  
	  console.log("to be edited ID = " + this.id);
	  
     this._issueService.getIssue(this.id).subscribe(
		(x:any) =>  this.product = x,
      err => console.log(err)
    );
	  
	  
	  
  }

  onSubmit(formValue: any){

	  
    console.log("Form to be udpated Value = " + JSON.stringify(formValue, null, 4));
    let updatedIssue = {
          id:this.product.id,
          description: formValue.description,
          name: formValue.name,
          manufacturer: formValue.manufacturer,
          price: formValue.price,
          quantity: formValue.quantity
          /*severity: formValue.severity,
          status: formValue.status,
          createdDate: formValue.createdDate,
		  resolvedDate: formValue.resolvedDate*/
        };
		
		console.log("Checking desc = " + updatedIssue.description );
		console.log("updatedIssue.id  = " + updatedIssue.id );
		
    this._issueService.updateIssue(updatedIssue).subscribe(
	(x:any) =>  this.router.navigate(['issues']),
      err => console.log(err)
	  ); 
	  
    //this.router.navigate(['issues']);
  }
}
