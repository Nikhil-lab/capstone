import { Injectable} from '@angular/core';
//import { Init } from "./initial-issues";
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable()
export class IssuesService {
	
	
	
	 private _productsUrl = "http://localhost:3000/products";
    private count=100;
    private httpOptions = {
        headers: new HttpHeaders({
			
          'Content-Type':  'application/json'
        })
    };
	
	constructor (private _http: HttpClient) { 
	
	console.log("Initializing Issues service ...");
	}
	

  getIssueCount() {
    let issues = this._http.get(this._productsUrl);
	let count=0;
    //return issues.length;
	
	var keys = Object.keys(issues);
	var len = keys.length;
	console.log("array keys:"+Object.keys(issues));
	console.log("array keys:"+len);
	return len;
	
	
  } 

  getIssues() {
    let issues = this._http.get(this._productsUrl);
    return issues;
  }

  getIssue(id: any) {
	  
	  let URL = `${this._productsUrl}/${id}`;
        return this._http.get(URL);

  }

 addIssue(newIssue: any) {
    let issues = newIssue;
     return this._http.post(this._productsUrl, issues, this.httpOptions);
    
  }

  updateIssue(updatedIssue: any) {
    
	console.log("updating...");
	console.log(updatedIssue.description);
	console.log(updatedIssue.id)
	let editproductsURL = `${this._productsUrl}/${updatedIssue.id}`;
     return this._http.put(editproductsURL,updatedIssue, this.httpOptions);
  }
  
 
	
	
	
  deleteIssue(id: any) {

	 let deleteProductsURL = `${this._productsUrl}/${id}`;
        return this._http.delete(deleteProductsURL);
	

  } 
}
