import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IssuesComponent } from './products.component';
import { IssueComponent } from './product.component';
import { AddIssueFormComponent } from './addproduct-form.component';
import { EditIssueFormComponent } from './editproduct-form.component';



const issuesRoutes: Routes = [
  
  { path: '', component: IssuesComponent },
  { path: ':id', component: IssueComponent },
  { path: 'addProduct', component: AddIssueFormComponent},
  { path: 'editProduct/:id', component: EditIssueFormComponent}
  
 /*{ 
    path: 'products', 
    children: [
      
      { path: 'addProduct', component: AddIssueFormComponent},
      { path: 'editProduct/:id', component: EditIssueFormComponent},
    ]
  }*/
  
];

@NgModule({
  imports: [
    RouterModule.forChild(issuesRoutes)
  ],
  exports: [ RouterModule ]
})

export class IssuesRoutingModule { }
