import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

import { IssuesService } from "./products.service";

@Component({
  selector: 'addproduct-form',
  templateUrl: './addproduct-form.component.html'
})
export class AddIssueFormComponent {

  products: any[];
  
  

  constructor(private _issueService: IssuesService, private router: Router) { }

  onSubmit(formValue: any){
    console.log("Form Value = " + JSON.stringify(formValue, null, 4));
    

    console.log("description 2ND TIME:"+formValue.description)
    let newProduct = {
		
          name: formValue.name,
          description: formValue.description,
          manufacturer: formValue.manufacturer,
          price: formValue.price,
          quantity: formValue.quantity,
          resolvedDate:formValue.resolvedDate,
          createdDate:formValue.createdDate

         
          
        };
		
		//console.log("NewIssue ID = " + this.count);
		
    this._issueService.addIssue(newProduct).subscribe(
	(x:any) =>  this.router.navigate(['issues']),
      err => console.log(err)
	
	);
    
  }
}
