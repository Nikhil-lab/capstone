import { NgModule } from '@angular/core';
import { IssuesComponent } from './products.component';
import { IssueComponent } from './product.component';
import { AddIssueFormComponent } from './addproduct-form.component';
import { EditIssueFormComponent } from './editproduct-form.component';
import { IssueFilterPipe } from './products-filter.pipe';
import { SharedModule } from '../shared/shared.module';
import { IssuesRoutingModule } from './products.routing';

@NgModule({
  imports: [ SharedModule,
    IssuesRoutingModule
  ],
  declarations: [ IssuesComponent, IssueComponent, AddIssueFormComponent, EditIssueFormComponent,IssueFilterPipe]
})
export class IssuesModule { }
