import { Component, OnInit } from '@angular/core';
import { IssuesService } from "./products.service";
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-issues',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class IssuesComponent implements OnInit {
  products: any[];

  constructor(private _issueService: IssuesService, private route: ActivatedRoute, private router: Router) { }

 
getFun(){ 


	this._issueService.getIssues().subscribe(
      (x:any) =>  this.products = x,
      err => console.log(err)
    );
	
}
  ngOnInit() {
     this.getFun();
  }
  
  

  deleteIssue(empid: any) {
	  
	  console.log("ID to be delted:"+empid);
    this._issueService.deleteIssue(empid).subscribe(
	
	(data:any) => this.getFun(),
	err => console.log(err)
    );
	
	
     this.router.navigate(['issues'])
  } 
}
