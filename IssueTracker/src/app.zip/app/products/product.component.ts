import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from "@angular/router";
import { Location } from "@angular/common";
import { IssuesService } from "./products.service";



@Component({
    templateUrl: './product.component.html',
    styleUrls: ['./product.component.css']
})
export class IssueComponent implements OnInit {
    id: any;
    issue: any;
    
    constructor(private _issueService: IssuesService, private route: ActivatedRoute, private location: Location) {
    }

    ngOnInit(): void {
        this.route.params.forEach((params: Params) => {
            this.id = +params['id'];
        });
		
		console.log("issue ID  from parameters:"+ this.id);
        this._issueService.getIssue(this.id).subscribe(
	(x:any) =>   this.issue =x,
      err => console.log(err)
	
	);
	
	console.log("issue values"+ this.issue.id);
	
		
    }

    goBack(): void {
        this.location.back();
    }
}
